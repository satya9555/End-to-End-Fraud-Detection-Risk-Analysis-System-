"""
Synthetic transaction data generator for fraud detection.
Produces realistic transaction records with embedded fraud patterns:
  - Odd-hour transactions
  - Sudden high-amount spikes relative to user history
  - Rapid-fire transactions (velocity abuse)
  - New-merchant / high-risk-category transactions
  - Geo-mismatch (transaction country != home country)
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

RNG = np.random.default_rng(42)

N_USERS = 2000
N_TRANSACTIONS = 60000
FRAUD_RATE = 0.018  # ~1.8% base fraud rate, realistic for card-not-present data

MERCHANT_CATEGORIES = [
    "grocery", "electronics", "travel", "dining", "utilities",
    "fashion", "gaming", "crypto_exchange", "wire_transfer", "jewelry",
    "gift_cards", "subscription", "pharmacy", "home_goods", "gas_station",
]
HIGH_RISK_CATEGORIES = {"crypto_exchange", "wire_transfer", "gift_cards", "jewelry"}

COUNTRIES = ["US", "US", "US", "US", "CA", "GB", "DE", "FR", "AU", "NG", "RU", "CN", "BR"]
HIGH_RISK_COUNTRIES = {"NG", "RU"}


def build_users(n_users: int) -> pd.DataFrame:
    home_countries = RNG.choice(["US", "CA", "GB", "DE", "FR", "AU"], size=n_users, p=[0.55, 0.1, 0.12, 0.08, 0.08, 0.07])
    avg_spend = np.round(RNG.gamma(shape=2.0, scale=45, size=n_users) + 15, 2)
    account_age_days = RNG.integers(30, 3650, size=n_users)
    risk_seed = RNG.random(n_users)  # latent propensity, not observed directly
    return pd.DataFrame({
        "user_id": np.arange(1, n_users + 1),
        "home_country": home_countries,
        "avg_spend": avg_spend,
        "account_age_days": account_age_days,
        "_risk_seed": risk_seed,
    })


def generate_transactions(users: pd.DataFrame, n_transactions: int) -> pd.DataFrame:
    start_time = datetime(2025, 1, 1)
    rows = []
    user_idx = RNG.integers(0, len(users), size=n_transactions)

    for i in range(n_transactions):
        u = users.iloc[user_idx[i]]
        is_fraud = RNG.random() < FRAUD_RATE

        ts = start_time + timedelta(seconds=int(RNG.integers(0, 300 * 24 * 3600)))

        if is_fraud:
            # ~22% of fraud is "sleeper" fraud that mimics normal behavior (hard to catch,
            # mirrors real-world account-takeover fraud that blends in)
            stealthy = RNG.random() < 0.22
            if stealthy:
                hour_choice = int(np.clip(RNG.normal(14, 5), 0, 23))
                ts = ts.replace(hour=hour_choice, minute=int(RNG.integers(0, 60)))
                amount = round(float(np.clip(RNG.normal(u["avg_spend"] * 1.3, u["avg_spend"] * 0.5), 3, None)), 2)
                category = RNG.choice(MERCHANT_CATEGORIES)
                country = u["home_country"] if RNG.random() < 0.7 else RNG.choice(COUNTRIES)
                time_since_last = RNG.exponential(3600 * 3)
                device_is_new = 1 if RNG.random() < 0.35 else 0
                distance_from_home_km = round(float(np.clip(RNG.exponential(40), 0, 400)), 1)
            else:
                hour_choice = RNG.choice([2, 3, 4, 23, 14], p=[0.3, 0.25, 0.15, 0.2, 0.1])
                ts = ts.replace(hour=hour_choice, minute=int(RNG.integers(0, 60)))
                amount = round(float(u["avg_spend"] * RNG.uniform(2, 10) + RNG.uniform(30, 300)), 2)
                category = RNG.choice(list(HIGH_RISK_CATEGORIES) + ["electronics", "gaming"],
                                       p=[0.22, 0.22, 0.18, 0.18, 0.12, 0.08])
                country = RNG.choice(list(HIGH_RISK_COUNTRIES) + [u["home_country"], "CN"],
                                      p=[0.3, 0.3, 0.2, 0.2])
                time_since_last = RNG.uniform(0.5, 90)
                device_is_new = 1 if RNG.random() < 0.6 else 0
                distance_from_home_km = round(float(RNG.uniform(150, 8000)), 1)
        else:
            # ~6% of legit transactions look unusual (false-positive-prone: travel, big
            # purchases, new devices) so the classes aren't perfectly separable
            unusual = RNG.random() < 0.06
            if unusual:
                hour_choice = RNG.choice([1, 23, 14, 20], p=[0.25, 0.25, 0.3, 0.2])
                ts = ts.replace(hour=hour_choice, minute=int(RNG.integers(0, 60)))
                amount = round(float(u["avg_spend"] * RNG.uniform(2, 6)), 2)
                category = RNG.choice(MERCHANT_CATEGORIES)
                country = RNG.choice(COUNTRIES)
                time_since_last = RNG.uniform(30, 600)
                device_is_new = 1 if RNG.random() < 0.5 else 0
                distance_from_home_km = round(float(RNG.uniform(200, 3000)), 1)
            else:
                hour_choice = int(np.clip(RNG.normal(14, 4.5), 0, 23))
                ts = ts.replace(hour=hour_choice, minute=int(RNG.integers(0, 60)))
                amount = round(float(np.clip(RNG.normal(u["avg_spend"], u["avg_spend"] * 0.4), 3, None)), 2)
                category = RNG.choice(MERCHANT_CATEGORIES)
                country = u["home_country"] if RNG.random() < 0.93 else RNG.choice(COUNTRIES)
                time_since_last = RNG.exponential(3600 * 6)
                device_is_new = 1 if RNG.random() < 0.04 else 0
                distance_from_home_km = round(float(np.clip(RNG.exponential(15), 0, 200)), 1)

        rows.append({
            "transaction_id": i + 1,
            "user_id": int(u["user_id"]),
            "timestamp": ts,
            "amount": amount,
            "merchant_category": category,
            "transaction_country": country,
            "home_country": u["home_country"],
            "account_age_days": int(u["account_age_days"]),
            "avg_user_spend": round(float(u["avg_spend"]), 2),
            "seconds_since_prev_txn": round(float(time_since_last), 1),
            "device_is_new": device_is_new,
            "distance_from_home_km": distance_from_home_km,
            "is_fraud": int(is_fraud),
        })

    df = pd.DataFrame(rows).sort_values("timestamp").reset_index(drop=True)
    return df


def main():
    users = build_users(N_USERS)
    txns = generate_transactions(users, N_TRANSACTIONS)
    out_path = "/home/claude/fraud_detection_system/data/transactions.csv"
    txns.drop(columns=[]).to_csv(out_path, index=False)
    print(f"Generated {len(txns)} transactions -> {out_path}")
    print(f"Fraud rate: {txns['is_fraud'].mean():.4%}")
    print(txns['is_fraud'].value_counts())


if __name__ == "__main__":
    main()
