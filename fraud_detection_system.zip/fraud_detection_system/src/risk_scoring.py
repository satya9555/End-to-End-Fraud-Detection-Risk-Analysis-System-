"""
Risk scoring layer: converts a raw fraud probability into a 0-100 risk score
and an actionable tier, mirroring how a real risk operations team would
route transactions.

Tiers:
  LOW       (0-29)  -> auto-approve
  MEDIUM    (30-59) -> soft challenge (step-up auth / OTP)
  HIGH      (60-84) -> hold for manual review
  CRITICAL  (85-100)-> auto-block + alert
"""
import sys
import joblib
import numpy as np
import pandas as pd

sys.path.insert(0, "/home/claude/fraud_detection_system/src")
from features import build_feature_matrix

MODEL_DIR = "/home/claude/fraud_detection_system/models"


def load_artifacts():
    model = joblib.load(f"{MODEL_DIR}/best_model.joblib")
    encoder = joblib.load(f"{MODEL_DIR}/encoder.joblib")
    scaler = joblib.load(f"{MODEL_DIR}/scaler.joblib")
    meta = joblib.load(f"{MODEL_DIR}/meta.joblib")
    return model, encoder, scaler, meta


def score_transactions(df: pd.DataFrame) -> pd.DataFrame:
    model, encoder, scaler, meta = load_artifacts()
    X, _, feat_df = build_feature_matrix(df, fit_encoder=encoder)

    if meta["best_model_name"] == "logistic_regression":
        X_input = scaler.transform(X)
        proba = model.predict_proba(X_input)[:, 1]
    else:
        proba = model.predict_proba(X)[:, 1]

    risk_score = np.round(proba * 100, 1)
    tier = pd.cut(
        risk_score, bins=[-0.1, 29.9, 59.9, 84.9, 100],
        labels=["LOW", "MEDIUM", "HIGH", "CRITICAL"]
    )
    action_map = {
        "LOW": "auto_approve",
        "MEDIUM": "step_up_auth",
        "HIGH": "manual_review",
        "CRITICAL": "auto_block_and_alert",
    }

    out = df.copy()
    out["fraud_probability"] = np.round(proba, 4)
    out["risk_score"] = risk_score
    out["risk_tier"] = tier.astype(str)
    out["recommended_action"] = out["risk_tier"].map(action_map)
    return out


def main():
    df = pd.read_csv("/home/claude/fraud_detection_system/data/transactions.csv", parse_dates=["timestamp"])
    sample = df.sample(n=min(2000, len(df)), random_state=7)
    scored = score_transactions(sample)
    out_path = "/home/claude/fraud_detection_system/reports/scored_sample.csv"
    scored.sort_values("risk_score", ascending=False).to_csv(out_path, index=False)
    print(scored["risk_tier"].value_counts())
    print(f"\nSaved scored sample -> {out_path}")

    # Quick sanity check: precision within CRITICAL tier
    crit = scored[scored["risk_tier"] == "CRITICAL"]
    if len(crit):
        print(f"CRITICAL tier fraud precision: {crit['is_fraud'].mean():.2%} ({len(crit)} txns)")


if __name__ == "__main__":
    main()
