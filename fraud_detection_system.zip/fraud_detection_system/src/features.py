"""
Feature engineering for the fraud detection system.
Transforms raw transaction records into model-ready features, including
derived risk signals that mirror what real fraud teams engineer:
  - amount_to_avg_ratio: how unusual is this amount for this user
  - is_odd_hour: transactions between midnight and 5am
  - is_high_risk_category / is_high_risk_country
  - is_cross_border: transaction country != home country
  - velocity flags from seconds_since_prev_txn
"""
import numpy as np
import pandas as pd

HIGH_RISK_CATEGORIES = {"crypto_exchange", "wire_transfer", "gift_cards", "jewelry"}
HIGH_RISK_COUNTRIES = {"NG", "RU"}

CATEGORICAL_COLS = ["merchant_category", "transaction_country", "home_country"]
NUMERIC_FEATURES = [
    "amount", "amount_to_avg_ratio", "account_age_days", "avg_user_spend",
    "seconds_since_prev_txn", "device_is_new", "distance_from_home_km",
    "is_odd_hour", "is_high_risk_category", "is_high_risk_country",
    "is_cross_border", "is_high_velocity", "hour",
]


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    df["hour"] = df["timestamp"].dt.hour

    df["amount_to_avg_ratio"] = (df["amount"] / df["avg_user_spend"].replace(0, np.nan)).fillna(1.0)
    df["is_odd_hour"] = df["hour"].apply(lambda h: 1 if h < 5 or h == 23 else 0)
    df["is_high_risk_category"] = df["merchant_category"].isin(HIGH_RISK_CATEGORIES).astype(int)
    df["is_high_risk_country"] = df["transaction_country"].isin(HIGH_RISK_COUNTRIES).astype(int)
    df["is_cross_border"] = (df["transaction_country"] != df["home_country"]).astype(int)
    df["is_high_velocity"] = (df["seconds_since_prev_txn"] < 60).astype(int)

    return df


def build_feature_matrix(df: pd.DataFrame, fit_encoder=None):
    """One-hot encode categoricals and assemble the final numeric matrix.
    Returns (X DataFrame, encoder) so the same encoder can be reused at inference time.
    """
    from sklearn.preprocessing import OneHotEncoder

    df = engineer_features(df)

    if fit_encoder is None:
        encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
        cat_encoded = encoder.fit_transform(df[CATEGORICAL_COLS])
    else:
        encoder = fit_encoder
        cat_encoded = encoder.transform(df[CATEGORICAL_COLS])

    cat_cols = encoder.get_feature_names_out(CATEGORICAL_COLS)
    cat_df = pd.DataFrame(cat_encoded, columns=cat_cols, index=df.index)

    X = pd.concat([df[NUMERIC_FEATURES], cat_df], axis=1)
    return X, encoder, df
