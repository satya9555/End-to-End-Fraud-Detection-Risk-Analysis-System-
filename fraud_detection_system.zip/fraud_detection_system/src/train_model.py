"""
Trains and compares multiple fraud detection models:
  - Logistic Regression (baseline, interpretable)
  - Random Forest (non-linear, handles interactions)
  - Gradient Boosting (typically strongest performer)
  - Isolation Forest (unsupervised anomaly detector, for comparison)

Handles class imbalance via class_weight='balanced'.
Saves the best supervised model + encoder + metrics to disk.
"""
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    roc_auc_score, average_precision_score, precision_recall_curve,
    roc_curve, confusion_matrix, classification_report, f1_score
)

import sys
sys.path.insert(0, "/home/claude/fraud_detection_system/src")
from features import build_feature_matrix

DATA_PATH = "/home/claude/fraud_detection_system/data/transactions.csv"
MODEL_DIR = "/home/claude/fraud_detection_system/models"
REPORT_DIR = "/home/claude/fraud_detection_system/reports"


def load_data():
    df = pd.read_csv(DATA_PATH, parse_dates=["timestamp"])
    return df


def main():
    df = load_data()
    X, encoder, feat_df = build_feature_matrix(df)
    y = df["is_fraud"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    results = {}
    fitted_models = {}

    # --- Logistic Regression ---
    lr = LogisticRegression(max_iter=1000, class_weight="balanced", random_state=42)
    lr.fit(X_train_scaled, y_train)
    fitted_models["logistic_regression"] = lr

    # --- Random Forest ---
    rf = RandomForestClassifier(
        n_estimators=300, max_depth=12, min_samples_leaf=3,
        class_weight="balanced", random_state=42, n_jobs=-1
    )
    rf.fit(X_train, y_train)
    fitted_models["random_forest"] = rf

    # --- Gradient Boosting ---
    gb = GradientBoostingClassifier(
        n_estimators=250, max_depth=3, learning_rate=0.08, random_state=42
    )
    # GradientBoostingClassifier has no class_weight; upweight via sample_weight
    sample_weight = np.where(y_train == 1, (y_train == 0).sum() / (y_train == 1).sum(), 1.0)
    gb.fit(X_train, y_train, sample_weight=sample_weight)
    fitted_models["gradient_boosting"] = gb

    # --- Isolation Forest (unsupervised anomaly detection baseline) ---
    iso = IsolationForest(n_estimators=200, contamination=float(y_train.mean()), random_state=42)
    iso.fit(X_train)
    fitted_models["isolation_forest"] = iso

    # --- Evaluate all models ---
    for name, model in fitted_models.items():
        if name == "logistic_regression":
            proba = model.predict_proba(X_test_scaled)[:, 1]
        elif name == "isolation_forest":
            raw = -model.decision_function(X_test)  # higher = more anomalous
            proba = (raw - raw.min()) / (raw.max() - raw.min())
        else:
            proba = model.predict_proba(X_test)[:, 1]

        preds = (proba >= 0.5).astype(int)
        auc = roc_auc_score(y_test, proba)
        ap = average_precision_score(y_test, proba)
        f1 = f1_score(y_test, preds)
        cm = confusion_matrix(y_test, preds).tolist()
        fpr, tpr, _ = roc_curve(y_test, proba)
        prec, rec, _ = precision_recall_curve(y_test, proba)

        results[name] = {
            "roc_auc": round(float(auc), 4),
            "avg_precision": round(float(ap), 4),
            "f1_score": round(float(f1), 4),
            "confusion_matrix": cm,
            "roc_curve": {"fpr": fpr[::max(1, len(fpr)//60)].tolist(), "tpr": tpr[::max(1, len(tpr)//60)].tolist()},
            "pr_curve": {"precision": prec[::max(1, len(prec)//60)].tolist(), "recall": rec[::max(1, len(rec)//60)].tolist()},
            "classification_report": classification_report(y_test, preds, output_dict=True),
        }
        print(f"\n=== {name} ===")
        print(f"ROC-AUC: {auc:.4f} | Avg Precision: {ap:.4f} | F1: {f1:.4f}")
        print(f"Confusion Matrix: {cm}")

    # Pick best supervised model by average precision (best metric for imbalanced fraud data)
    supervised = {k: v for k, v in results.items() if k != "isolation_forest"}
    best_name = max(supervised, key=lambda k: supervised[k]["avg_precision"])
    print(f"\nBest model: {best_name}")

    # Feature importance (for tree-based best model, else coefficients)
    feature_names = list(X.columns)
    best_model = fitted_models[best_name]
    if hasattr(best_model, "feature_importances_"):
        importances = best_model.feature_importances_
    elif hasattr(best_model, "coef_"):
        importances = np.abs(best_model.coef_[0])
    else:
        importances = np.zeros(len(feature_names))
    top_features = sorted(zip(feature_names, importances), key=lambda x: -x[1])[:15]
    results["top_features"] = [{"feature": f, "importance": round(float(v), 5)} for f, v in top_features]
    results["best_model"] = best_name
    results["test_set_size"] = int(len(y_test))
    results["fraud_count_test"] = int(y_test.sum())
    results["feature_names"] = feature_names

    # Save artifacts
    joblib.dump(best_model, f"{MODEL_DIR}/best_model.joblib")
    joblib.dump(encoder, f"{MODEL_DIR}/encoder.joblib")
    joblib.dump(scaler, f"{MODEL_DIR}/scaler.joblib")
    joblib.dump({"best_model_name": best_name, "feature_names": feature_names}, f"{MODEL_DIR}/meta.joblib")

    with open(f"{REPORT_DIR}/metrics.json", "w") as f:
        json.dump(results, f, indent=2)

    print(f"\nSaved best model ({best_name}) and metrics to {MODEL_DIR} / {REPORT_DIR}")


if __name__ == "__main__":
    main()
