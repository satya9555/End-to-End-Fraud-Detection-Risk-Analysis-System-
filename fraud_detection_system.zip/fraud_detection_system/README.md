# End-to-End Fraud Detection & Risk Analysis System

A complete, runnable fraud detection pipeline: synthetic transaction data → feature
engineering → model training/comparison → risk scoring → an interactive dashboard.

**Live dashboard:** open `dashboard.html` (also published as a shareable Claude artifact)
to explore model performance, risk tiers, the highest-risk transactions, and a
"score a transaction" simulator.

## Results at a glance

On a held-out test set of 15,000 transactions (1.8% fraud rate):

| Model | ROC-AUC | Avg. Precision | F1 |
|---|---|---|---|
| Logistic Regression | 0.946 | 0.790 | 0.356 |
| Random Forest | 0.974 | 0.872 | 0.866 |
| **Gradient Boosting (best)** | **0.972** | **0.874** | 0.647 |
| Isolation Forest (unsupervised) | 0.929 | 0.736 | 0.435 |

Routing outcome across all 60,000 transactions:
- **94.4%** auto-approved with zero friction (LOW tier, 0.06% actually fraud)
- **83%** precision in the CRITICAL tier — when the system says block, it's right 5 times out of 6
- **92%** of all fraud is caught in the HIGH + CRITICAL tiers combined

## Project structure

```
fraud_detection_system/
├── src/
│   ├── generate_data.py     # Synthetic transaction generator (60k txns, 2k users)
│   ├── features.py          # Feature engineering + one-hot encoding
│   ├── train_model.py       # Trains & compares 4 models, saves the best one
│   └── risk_scoring.py      # Converts probabilities into risk tiers + actions
├── data/
│   └── transactions.csv     # Generated dataset
├── models/
│   ├── best_model.joblib    # Trained Gradient Boosting model
│   ├── encoder.joblib       # Fitted one-hot encoder
│   ├── scaler.joblib        # Fitted StandardScaler (used if best model is logistic regression)
│   └── meta.joblib          # Model metadata (name, feature list)
├── reports/
│   ├── metrics.json         # Full evaluation metrics for all 4 models
│   ├── scored_sample.csv    # Risk-scored sample transactions
│   ├── tier_summary.json / top30.json / overall_summary.json  # Dashboard data
├── dashboard.html           # Self-contained interactive dashboard
└── README.md
```

## How it works

**1. Data generation** (`generate_data.py`)
Simulates 2,000 users and 60,000 transactions. ~1.8% are fraudulent, split between
"obvious" fraud (odd hours, high-risk merchants like crypto exchanges and wire
transfers, large amount spikes, rapid-fire velocity, foreign countries) and
~22% "stealthy" fraud that mimics normal behavior — so the problem isn't
trivially separable, like real fraud data.

**2. Feature engineering** (`features.py`)
Derives the signals a real fraud team would build:
- `amount_to_avg_ratio` — how unusual is this amount for this specific user
- `is_odd_hour`, `is_high_risk_category`, `is_high_risk_country`
- `is_cross_border` — transaction country vs. home country
- `is_high_velocity` — seconds since the user's previous transaction
- One-hot encoded merchant category and country

**3. Model training** (`train_model.py`)
Trains and compares four approaches on a stratified 75/25 split:
- Logistic Regression (interpretable baseline)
- Random Forest
- Gradient Boosting (best performer, selected automatically by average precision)
- Isolation Forest (unsupervised anomaly detection, for comparison)

Class imbalance is handled via `class_weight="balanced"` (RF/LR) or manual
`sample_weight` (Gradient Boosting), since only ~1.8% of transactions are fraud.

**4. Risk scoring** (`risk_scoring.py`)
Converts the model's fraud probability into a 0–100 risk score and a tier:

| Tier | Score | Action |
|---|---|---|
| LOW | 0–29 | Auto-approve |
| MEDIUM | 30–59 | Step-up authentication (OTP) |
| HIGH | 60–84 | Hold for manual review |
| CRITICAL | 85–100 | Auto-block + alert |

**5. Dashboard** (`dashboard.html`)
A self-contained HTML file (Chart.js via CDN, no build step) showing model
comparison, ROC curves, feature importance, risk-tier distribution, the 30
highest-risk transactions, and an interactive simulator that shows how each
signal moves a transaction's score.

## Running it yourself

Requires Python 3.10+ with `pandas`, `numpy`, `scikit-learn`, `joblib`.

```bash
cd src
python3 generate_data.py     # writes data/transactions.csv
python3 train_model.py       # trains all 4 models, saves the best one + metrics.json
python3 risk_scoring.py      # scores a sample, writes reports/scored_sample.csv
```

To score new transactions programmatically:

```python
from risk_scoring import score_transactions
import pandas as pd

df = pd.read_csv("your_transactions.csv", parse_dates=["timestamp"])
scored = score_transactions(df)  # adds fraud_probability, risk_score, risk_tier, recommended_action
```

## Extending this to production

This is a demonstration pipeline on synthetic data. For production use, consider:
- Streaming feature computation (velocity/geo features need real-time state, not batch CSVs)
- Model monitoring for drift as fraud patterns evolve
- A feedback loop from confirmed fraud/chargebacks back into training data
- Explainability tooling (e.g. SHAP) for manual review analysts
- A/B testing risk thresholds against business cost of false positives vs. missed fraud
